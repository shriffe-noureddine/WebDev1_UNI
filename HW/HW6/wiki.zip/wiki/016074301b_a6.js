let seed = '016074301b';

function rand () {
    if (typeof seed != 'number') seed = Number(seed.match(/\d+/g));
    var x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
}

// rand() returns a number {0,1}, multiply it with {0,16} and round it, then return it as a string base 16
let randomColor = '#' + Math.round(rand() * 0xFFFFFF).toString(16);



// get the value of style and the random color; and save them as items in localStorage
localStorage.setItem('imageStyle', `thick solid ${randomColor}`);
localStorage.setItem('hrefStyle', `${randomColor}`);

/**
 * create an array of all the images in the document, iterate and set the border style
 * of first child to the local storage item "imageStyle".
 */
let image = document.getElementsByClassName('image');
for (let i = 0; i < image.length; i++) {
    image[i].firstElementChild.style.border = localStorage.getItem('imageStyle');
}

/**
 * create an array of all the anchors in the document, 
 * iterate and if the href attribute contains the string “wikipedia”
 * set the background color of the anchor tag to the value of the localStorage item “hrefStyle”.
 */
let anchors = document.querySelectorAll('a');
for (let i = 0; i < anchors.length; i++) {
    let href = anchors[i].href;
    if (href.includes("wikipedia")) {
        anchors[i].style.backgroundColor = localStorage.getItem('hrefStyle');
    }    
}


