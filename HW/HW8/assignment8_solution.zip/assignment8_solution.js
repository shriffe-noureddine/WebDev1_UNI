// The goal of this coding assignment is to download a very large PDF file asynchronously
// and to show the download progress in both visual and textual form.
let xhr = new XMLHttpRequest();
// This PDF is stored in a server that will accept requests from any domain,
// in order to avoid CORS issues.
xhr.open('GET', 'https://luis.leiva.name/ajax/bnaic2021_preproceedings.pdf');
xhr.send();

// We have in the HTML a <progress> and a <span> element with IDs "file" and "perc".
let file = document.getElementById('file');
let perc = document.getElementById('perc');

// Track download progress.
xhr.onprogress = function(event) {
  // NB: Assume `event.lengthComputable` is defined (this is so in modern browers).
  let prog = Math.round(100 * event.loaded / event.total);
  // Update the progress bar.
  file.setAttribute('value', prog);
  // Update the progress counter (the span element).
  perc.textContent = prog + '%';
};

// On pressing ESC abort the download.
document.addEventListener('keydown', function(ev) {
  if (ev.key == "Escape") xhr.abort();
});

// Verify there were no errors at the end, otherwise alert the user.
xhr.onload = function() {
  if (xhr.status != 200) {
    alert(`Error ${xhr.status}: ${xhr.statusText}`);
  }
};

// Bonus: check for errors during the download.
xhr.onerror = function() {
  alert("Request failed");
};
